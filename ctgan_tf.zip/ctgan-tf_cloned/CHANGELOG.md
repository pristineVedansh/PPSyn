# Changelog

### v0.1.4 - 2020-06-02

Migrating to TensorFlow 2.2.0. Mainly updated unit tests.

### v0.1.1-v0.1.3 - 2020-05-06

Multiple changes to optimize CI/CD deployment.

## v0.1.0 - 2020-05-01

First Release - Initial TensorFlow 2.1 implementation of CTGAN.