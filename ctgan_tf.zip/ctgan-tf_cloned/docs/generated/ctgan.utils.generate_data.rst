:mod:`ctgan.utils`.generate_data
=============================================

.. currentmodule:: ctgan.utils

.. autofunction:: generate_data

.. raw:: html

    <div style='clear:both'></div>