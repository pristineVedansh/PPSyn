:mod:`ctgan.layers`.ResidualLayer
========================================

.. currentmodule:: ctgan.layers

.. autoclass:: ResidualLayer
   
   .. automethod:: __init__

   

.. raw:: html

    <div style='clear:both'></div>