:mod:`ctgan.models`.BGM
==============================

.. currentmodule:: ctgan.models

.. autoclass:: BGM
   
   .. automethod:: __init__

   

.. raw:: html

    <div style='clear:both'></div>