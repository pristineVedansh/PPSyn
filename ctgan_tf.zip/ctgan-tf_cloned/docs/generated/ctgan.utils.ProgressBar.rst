:mod:`ctgan.utils`.ProgressBar
=====================================

.. currentmodule:: ctgan.utils

.. autoclass:: ProgressBar
   
   .. automethod:: __init__

   

.. raw:: html

    <div style='clear:both'></div>