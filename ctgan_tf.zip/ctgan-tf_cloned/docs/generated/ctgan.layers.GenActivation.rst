:mod:`ctgan.layers`.GenActivation
========================================

.. currentmodule:: ctgan.layers

.. autoclass:: GenActivation
   
   .. automethod:: __init__

   

.. raw:: html

    <div style='clear:both'></div>