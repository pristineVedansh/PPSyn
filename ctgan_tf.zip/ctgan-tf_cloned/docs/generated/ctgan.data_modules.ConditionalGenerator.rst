:mod:`ctgan.data_modules`.ConditionalGenerator
=====================================================

.. currentmodule:: ctgan.data_modules

.. autoclass:: ConditionalGenerator
   
   .. automethod:: __init__

   

.. raw:: html

    <div style='clear:both'></div>