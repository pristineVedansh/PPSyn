:mod:`ctgan.data_modules`.DataTransformer
================================================

.. currentmodule:: ctgan.data_modules

.. autoclass:: DataTransformer
   
   .. automethod:: __init__

   

.. raw:: html

    <div style='clear:both'></div>