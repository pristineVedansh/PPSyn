:mod:`ctgan.layers`.init_bounded
=============================================

.. currentmodule:: ctgan.layers

.. autofunction:: init_bounded

.. raw:: html

    <div style='clear:both'></div>