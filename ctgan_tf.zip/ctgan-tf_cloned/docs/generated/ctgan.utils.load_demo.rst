:mod:`ctgan.utils`.load_demo
=========================================

.. currentmodule:: ctgan.utils

.. autofunction:: load_demo

.. raw:: html

    <div style='clear:both'></div>