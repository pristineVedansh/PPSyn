:mod:`ctgan.utils`.get_test_variables
==================================================

.. currentmodule:: ctgan.utils

.. autofunction:: get_test_variables

.. raw:: html

    <div style='clear:both'></div>