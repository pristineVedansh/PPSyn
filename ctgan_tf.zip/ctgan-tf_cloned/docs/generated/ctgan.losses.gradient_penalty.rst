:mod:`ctgan.losses`.gradient_penalty
=================================================

.. currentmodule:: ctgan.losses

.. autofunction:: gradient_penalty

.. raw:: html

    <div style='clear:both'></div>