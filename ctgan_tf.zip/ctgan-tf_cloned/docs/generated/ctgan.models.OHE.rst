:mod:`ctgan.models`.OHE
==============================

.. currentmodule:: ctgan.models

.. autoclass:: OHE
   
   .. automethod:: __init__

   

.. raw:: html

    <div style='clear:both'></div>