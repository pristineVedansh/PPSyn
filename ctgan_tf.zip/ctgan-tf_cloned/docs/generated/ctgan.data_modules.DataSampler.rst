:mod:`ctgan.data_modules`.DataSampler
============================================

.. currentmodule:: ctgan.data_modules

.. autoclass:: DataSampler
   
   .. automethod:: __init__

   

.. raw:: html

    <div style='clear:both'></div>