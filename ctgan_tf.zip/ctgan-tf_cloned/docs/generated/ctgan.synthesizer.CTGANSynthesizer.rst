:mod:`ctgan.synthesizer`.CTGANSynthesizer
================================================

.. currentmodule:: ctgan.synthesizer

.. autoclass:: CTGANSynthesizer
   
   .. automethod:: __init__

   

.. raw:: html

    <div style='clear:both'></div>