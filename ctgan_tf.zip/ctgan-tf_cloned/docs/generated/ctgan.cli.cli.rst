:mod:`ctgan.cli`.cli
=================================

.. currentmodule:: ctgan.cli

.. autofunction:: cli

.. raw:: html

    <div style='clear:both'></div>