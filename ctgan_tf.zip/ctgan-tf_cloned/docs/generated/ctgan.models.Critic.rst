:mod:`ctgan.models`.Critic
=================================

.. currentmodule:: ctgan.models

.. autoclass:: Critic
   
   .. automethod:: __init__

   

.. raw:: html

    <div style='clear:both'></div>