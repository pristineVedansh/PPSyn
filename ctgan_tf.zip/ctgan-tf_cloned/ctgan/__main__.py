"""
Module that proxies the execution to the command-line interface.
"""
from ctgan import cli


if __name__ == '__main__':
    cli.cli()
